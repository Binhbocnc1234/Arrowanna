

struct Vector{
    int x, y;
};