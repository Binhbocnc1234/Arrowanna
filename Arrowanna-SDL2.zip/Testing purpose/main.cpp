#include <bits/stdc++.h>
#include "Ulti.h"
using namespace std;

int main(){
    auto a = Vector();
    cout << a.x << ' ' << a.y;
}